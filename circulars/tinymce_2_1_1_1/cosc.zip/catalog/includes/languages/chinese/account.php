<?php
/*
  $Id: account.php,v 1.1.1.1 2002/11/07 03:16:47 nickle Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 osCommerce
  Released under the GNU General Public License

*/

define('NAVBAR_TITLE', '�ҵ��ʺ�');
define('HEADING_TITLE', '�ҵ��ʺ�����');
?>