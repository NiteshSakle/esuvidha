<?php
/*
  $Id: account_edit.php,v 1.1.1.1 2002/11/07 03:16:47 nickle Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 osCommerce
  Released under the GNU General Public License

 
*/

define('NAVBAR_TITLE_1', '�ҵ��ʺ�');
define('NAVBAR_TITLE_2', '�޸��ʺ�');
define('HEADING_TITLE', '�ҵ��ʺ�����');
?>