<?php
/*
  $Id: address_book_process.php,v 1.1.1.1 2002/11/07 03:16:48 nickle Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 osCommerce
  Released under the GNU General Public License

 
*/

define('NAVBAR_TITLE_1', '�ҵ��ʺ�');
define('NAVBAR_TITLE_2', 'ͨѶ¼');
define('NAVBAR_TITLE_ADD_ENTRY', '�¼�¼');
define('NAVBAR_TITLE_MODIFY_ENTRY', '�޸ļ�¼');
define('HEADING_TITLE_ADD_ENTRY', '�¼�¼');
define('HEADING_TITLE_MODIFY_ENTRY', '��¼');
?>