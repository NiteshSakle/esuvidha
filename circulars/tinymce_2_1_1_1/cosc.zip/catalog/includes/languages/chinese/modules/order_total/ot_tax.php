<?php
/*
  $Id: ot_tax.php,v 1.1 2002/04/03 23:09:49 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_TAX_TITLE', '˰');
  define('MODULE_ORDER_TOTAL_TAX_DESCRIPTION', '����˰');
?>